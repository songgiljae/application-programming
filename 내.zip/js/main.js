function searchItems() {
    let input = document.getElementById('searchInput').value.toLowerCase();
    let items = document.getElementById('itemsList').getElementsByTagName('li');
  
    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let text = item.textContent || item.innerText;
    
        if (text.toLowerCase().includes(input)) {
            item.style.display = "";
        } else {
            item.style.display = "none";
        }
    }
}

function autoComplete() {
    let input = document.getElementById('autoComplete').value.toLowerCase();
    let suggestionsList = document.getElementById('suggestions');
    suggestionsList.innerHTML = ""; 
  
    if (input.length > 0) {
        let filteredSuggestions = recipes.filter(recipe => recipe.toLowerCase().includes(input));
    
        filteredSuggestions.forEach(suggestion => {
            let listItem = document.createElement('li');
            listItem.textContent = suggestion;
            listItem.addEventListener('click', function() {
                document.getElementById('autoComplete').value = suggestion;
                suggestionsList.innerHTML = ""; 
            });
            suggestionsList.appendChild(listItem);
        });
    }
}

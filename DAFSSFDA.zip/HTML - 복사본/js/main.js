const recipes = {
    '비빔밥': {
        image: 'imges/비빔밥.jpg',
        ingredients: ['밥', '고추장', '계란', '소고기', '야채'],
        instructions: '1. 밥을 준비한다.\n2. 고추장과 계란을 준비한다.\n3. 야채를 썰어 볶는다.',
        nutrition: '칼로리: 500kcal\n단백질: 20g\n탄수화물: 70g',
        comments: [] // 댓글 배열
    },
    '불고기': {
        image: 'imges/불고기.jpg',
        ingredients: ['소고기', '양파', '대파', '마늘', '간장'],
        instructions: '1. 소고기를 양념에 재운다.\n2. 팬에 구워서 먹는다.',
        nutrition: '칼로리: 350kcal\n단백질: 25g\n지방: 20g',
        comments: [] // 댓글 배열
    },
    '갈비찜': {
        image: 'imges/갈비찜.jpg',
        ingredients: ['갈비', '간장', '마늘', '양파', '배'],
        instructions: '1. 갈비를 손질하고, 양념을 만든다.\n2. 갈비를 양념에 재운 후 끓인다.',
        nutrition: '칼로리: 700kcal\n단백질: 45g\n지방: 50g',
        comments: [] // 댓글 배열
    },
    '김밥': {
        image: 'imges/김밥.jpg',
        ingredients: ['김', '밥', '오이', '당근', '단무지', '계란'],
        instructions: '1. 밥에 양념을 하고 재료를 준비한다.\n2. 김에 밥을 얇게 펼친 후 재료를 놓고 말아준다.',
        nutrition: '칼로리: 250kcal\n단백질: 6g\n탄수화물: 40g',
        comments: [] // 댓글 배열
    },
    '김치찌개': {
        image: 'imges/김치찌개.jpg',
        ingredients: ['김치', '두부', '돼지고기', '양파', '마늘'],
        instructions: '1. 돼지고기와 김치를 볶는다.\n2. 물을 넣고 끓인 후 두부와 양파를 넣는다.',
        nutrition: '칼로리: 300kcal\n단백질: 20g\n지방: 15g',
        comments: [] // 댓글 배열
    },
    '된장찌개': {
        image: 'imges/된장찌개.jpg',
        ingredients: ['된장', '두부', '감자', '양파', '마늘'],
        instructions: '1. 된장을 풀고 감자와 양파를 넣는다.\n2. 끓이다가 두부를 넣고 더 끓인다.',
        nutrition: '칼로리: 200kcal\n단백질: 15g\n탄수화물: 25g',
        comments: [] // 댓글 배열
    },
    '떡볶이': {
        image: 'imges/떡볶이.jpg',
        ingredients: ['떡', '어묵', '고추장', '설탕', '파'],
        instructions: '1. 떡과 어묵을 준비한다.\n2. 고추장과 설탕으로 양념장을 만든 후 끓인다.',
        nutrition: '칼로리: 400kcal\n단백질: 10g\n탄수화물: 70g',
        comments: [] // 댓글 배열
    },
    '순두부찌개': {
        image: 'imges/순두부찌개.jpg',
        ingredients: ['순두부', '고기', '양파', '마늘', '국간장'],
        instructions: '1. 고기와 양파를 볶은 후 물을 넣고 끓인다.\n2. 순두부를 넣고 간을 맞춘다.',
        nutrition: '칼로리: 250kcal\n단백질: 15g\n지방: 12g',
        comments: [] // 댓글 배열
    },
    '잡채': {
        image: 'imges/잡체.jpg',
        ingredients: ['당면', '소고기', '당근', '버섯', '간장', '참기름'],
        instructions: '1. 당면을 삶고, 소고기와 채소를 볶는다.\n2. 당면과 볶은 재료를 섞어 간을 맞춘다.',
        nutrition: '칼로리: 450kcal\n단백질: 20g\n탄수화물: 60g',
        comments: [] // 댓글 배열
    },
    '칼국수': {
        image: 'imges/순두부찌개.jpg', // 칼국수 이미지로 변경해야 할 수도 있음
        ingredients: ['칼국수 면', '닭고기', '양파', '마늘', '국물'],
        instructions: '1. 닭고기를 끓여 국물을 만든다.\n2. 칼국수 면을 넣고 끓여서 완성한다.',
        nutrition: '칼로리: 350kcal\n단백질: 25g\n탄수화물: 45g',
        comments: [] // 댓글 배열
    }
};



// 메뉴 열기/닫기 상태 관리
function toggleMenu() {
    const sideMenu = document.querySelector(".side-menu");
    sideMenu.classList.toggle("open"); // 메뉴 열림 상태 변경
}

// 닫기 버튼 기능
function closeMenu() {
    const sideMenu = document.querySelector(".side-menu");
    sideMenu.classList.remove("open"); // 열림 상태 제거
}





// 슬라이더 애니메이션
let currentSlide = 0;
const slides = document.querySelectorAll('.img_slider img');

function showNextSlide() {
    slides[currentSlide].style.display = 'none'; // 현재 슬라이드 숨기기
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].style.display = 'block'; // 다음 슬라이드 보이기
}

setInterval(showNextSlide, 3000); // 3초마다 슬라이드 변경

// 레시피 추가
function addRecipe() {
    const title = document.getElementById("recipeTitle").value;
    const description = document.getElementById("recipeDescription").value;
    const image = document.getElementById("recipeImage").files[0];

    if (!title || !description || !image) {
        alert("모든 항목을 입력해주세요.");
        return;
    }

    const recipe = {
        title: title,
        description: description,
        image: URL.createObjectURL(image)
    };

    let recipes = JSON.parse(localStorage.getItem("recipes")) || [];
    recipes.push(recipe);
    localStorage.setItem("recipes", JSON.stringify(recipes));

    displayRecipes();
}

// 레시피 목록 표시
function displayRecipes() {
    const recipeList = document.getElementById("recipeList");
    recipeList.innerHTML = '';

    const recipes = JSON.parse(localStorage.getItem("recipes")) || [];

    recipes.forEach((recipe, index) => {
        const recipeDiv = document.createElement("div");
        recipeDiv.classList.add("recipe");

        const recipeImg = document.createElement("img");
        recipeImg.src = recipe.image;
        recipeDiv.appendChild(recipeImg);

        const recipeTitle = document.createElement("h4");
        recipeTitle.textContent = recipe.title;
        recipeDiv.appendChild(recipeTitle);

        const recipeDescription = document.createElement("p");
        recipeDescription.textContent = recipe.description;
        recipeDiv.appendChild(recipeDescription);

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "삭제";
        deleteButton.onclick = () => deleteRecipe(index);
        recipeDiv.appendChild(deleteButton);

        recipeList.appendChild(recipeDiv);
    });
}

// 레시피 삭제
function deleteRecipe(index) {
    let recipes = JSON.parse(localStorage.getItem("recipes")) || [];
    recipes.splice(index, 1);
    localStorage.setItem("recipes", JSON.stringify(recipes));
    displayRecipes();
}

// 댓글 추가
function addComment() {
    const commentText = document.getElementById("commentText").value;

    if (!commentText) {
        alert("댓글을 입력해주세요.");
        return;
    }

    let comments = JSON.parse(localStorage.getItem("comments")) || [];
    comments.push(commentText);
    localStorage.setItem("comments", JSON.stringify(comments));

    displayComments();
}

// 댓글 목록 표시
function displayComments() {
    const commentList = document.getElementById("commentList");
    commentList.innerHTML = '';

    const comments = JSON.parse(localStorage.getItem("comments")) || [];

    comments.forEach(comment => {
        const commentDiv = document.createElement("div");
        commentDiv.classList.add("comment");
        commentDiv.textContent = comment;
        commentList.appendChild(commentDiv);
    });
}

// 페이지 로드 시 레시피 및 댓글 표시
document.addEventListener("DOMContentLoaded", () => {
    displayRecipes();
    displayComments();
});




// 레시피 상세보기 모달 열기
function openRecipeModal(recipeName) {
    const recipe = recipes[recipeName];

    // 모달에 레시피 정보 채우기
    document.getElementById('modalTitle').innerText = recipeName;
    document.getElementById('modalImage').src = recipe.image;
    document.getElementById('modalIngredients').innerHTML = `<h3>재료</h3><ul>${recipe.ingredients.map(i => `<li>${i}</li>`).join('')}</ul>`;
    document.getElementById('modalInstructions').innerHTML = `<h3>만드는 법</h3><p>${recipe.instructions}</p>`;
    document.getElementById('modalNutrition').innerHTML = `<h3>영양 정보</h3><p>${recipe.nutrition}</p>`;

    // 댓글 로드
    loadComments(recipeName);

    // 모달 열기
    document.getElementById('recipeModal').style.display = 'block';
}

// 모달 닫기
function closeRecipeModal() {
    document.getElementById('recipeModal').style.display = 'none';
}

// 댓글 추가
function addComment() {
    const recipeName = document.getElementById('modalTitle').innerText;
    const author = document.getElementById('commentAuthor').value;
    const text = document.getElementById('commentText').value;

    if (author && text) {
        const newComment = { author, text };

        // 해당 레시피에 댓글 추가
        recipes[recipeName].comments.push(newComment);

        // 댓글 추가 후, 댓글을 다시 로드
        loadComments(recipeName);
        
        // 입력창 초기화
        document.getElementById('commentAuthor').value = '';
        document.getElementById('commentText').value = '';
    }
}

// 댓글 로드
function loadComments(recipeName) {
    const comments = recipes[recipeName].comments;
    const commentList = document.getElementById('commentList');
    commentList.innerHTML = ''; // 기존 댓글 지우기

    comments.forEach(comment => {
        const commentDiv = document.createElement('div');
        commentDiv.classList.add('comment');
        commentDiv.innerHTML = `<strong>${comment.author}</strong><p>${comment.text}</p>`;
        commentList.appendChild(commentDiv);
    });
}

// 레시피 목록 클릭 시 상세보기
function displayRecipes() {
    const recipeList = document.getElementById("recipeList");
    recipeList.innerHTML = '';

    const recipesList = Object.keys(recipes); // '비빔밥', '불고기' 등

    recipesList.forEach(recipeName => {
        const recipeDiv = document.createElement("div");
        recipeDiv.classList.add("recipe");
        recipeDiv.onclick = () => openRecipeModal(recipeName); // 클릭 시 모달 열기

        const recipeImg = document.createElement("img");
        recipeImg.src = recipes[recipeName].image;
        recipeDiv.appendChild(recipeImg);

        const recipeTitle = document.createElement("h4");
        recipeTitle.textContent = recipeName;
        recipeDiv.appendChild(recipeTitle);

        const recipeDescription = document.createElement("p");
        recipeDescription.textContent = "간단한 설명";
        recipeDiv.appendChild(recipeDescription);

        recipeList.appendChild(recipeDiv);
    });
}

// 페이지 로드 시 레시피 및 댓글 표시
document.addEventListener("DOMContentLoaded", () => {
    displayRecipes();
});



// 검색 입력 이벤트 처리
document.getElementById("searchInput").addEventListener("input", displayRecipes);

function displayRecipes() {
    const searchQuery = document.getElementById("searchInput").value.toLowerCase(); // 검색어
    const recipeList = document.getElementById("recipeList");
    recipeList.innerHTML = ''; // 기존 목록 초기화

    const recipesList = Object.keys(recipes); // '비빔밥', '불고기' 등

    recipesList.forEach(recipeName => {
        // 검색어가 레시피 이름에 포함되면
        if (recipeName.toLowerCase().includes(searchQuery)) {
            const recipeDiv = document.createElement("div");
            recipeDiv.classList.add("recipe");
            recipeDiv.onclick = () => openRecipeModal(recipeName); // 클릭 시 모달 열기

            const recipeImg = document.createElement("img");
            recipeImg.src = recipes[recipeName].image;
            recipeDiv.appendChild(recipeImg);

            const recipeTitle = document.createElement("h4");
            recipeTitle.textContent = recipeName;
            recipeDiv.appendChild(recipeTitle);

            const recipeDescription = document.createElement("p");
            recipeDescription.textContent = "간단한 설명";
            recipeDiv.appendChild(recipeDescription);

            recipeList.appendChild(recipeDiv);
        }
    });
}

// 페이지 로드 시 레시피 목록 표시
document.addEventListener("DOMContentLoaded", () => {
    displayRecipes(); // 최초 레시피 표시
});

// 햄버거 메뉴 열기/닫기
function toggleMenu() {
    const sideMenu = document.querySelector(".side-menu");
    sideMenu.classList.toggle("open"); // 메뉴 열림 상태 변경
}

// 메뉴 닫기
function closeMenu() {
    const sideMenu = document.querySelector(".side-menu");
    sideMenu.classList.remove("open"); // 열림 상태 제거
}

// 페이지 이동 (예시로 anchor를 사용해 이동)
function navigateTo(page) {
    if (page === 'home') {
        window.location.href = '#home'; // 홈으로 이동
    } else if (page === 'about') {
        window.location.href = '#about'; // 사이트 소개로 이동
    } else if (page === 'usage') {
        window.location.href = '#usage'; // 사용방법으로 이동
    } else if (page === 'my-recipes') {
        window.location.href = '#my-recipes'; // 나만의 레시피로 이동
    }
}



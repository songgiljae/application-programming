// 햄버거 메뉴 열기/닫기
function toggleMenu() {
    const menuList = document.querySelector(".menu_list");
    menuList.classList.toggle("active"); 
}

// 한식, 중식, 양식 구분
function filterRecipes(category) {
    document.querySelectorAll('.rectangle').forEach(container => {
        container.style.display = container.getAttribute('data-category') === category || category === '전체' ? 'block' : 'none';
    });
}

// 레시피 검색 기능
function searchRecipes() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('.rectangle').forEach(recipe => {
        recipe.style.display = recipe.querySelector('h2').innerText.toLowerCase().includes(input) ? 'block' : 'none';
    });
}
